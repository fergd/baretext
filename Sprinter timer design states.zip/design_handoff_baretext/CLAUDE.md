# CLAUDE.md — Baretext design handoff

You are implementing designs for **Baretext**, a macOS Electron writing app. This folder is a **design reference package** created in HTML — prototypes of the intended look and behavior, **not** production code to copy verbatim. Recreate these designs in this repo's existing stack (React/Electron) using its established patterns; port the CSS custom properties as-is, but rebuild the markup/components idiomatically.

## Read these first, in order
1. `README.md` — full design spec: all screens (Sprinter, Editor, Typewriter), layout measurements, components, interactions, state.
2. `THEMES.md` — **authoritative theme spec**: the 5 themes, every semantic token value, cursor exceptions, and a build guide for the in-app **Theme Picker** view.
3. `TYPEWRITER_MODE.md` — Typewriter mode spec (focus dimming, center guide, edge fades).

## The theme system (drop-in)
The design is fully tokenized. Port these two files as the styling foundation, then reference the tokens everywhere — never hard-code colors:
- `tokens/colors.css` — 5 themes (`dark`=Ember, `light`=Parchment, `amstrad`, `grove`, `dracula`), each a block of semantic custom properties keyed to `[data-theme="…"]`. `:root` = Ember (default).
- `tokens/effects.css` — radii, shadows, motion, and **derived** tokens (glass, washes, keycaps). ⚠ The derived tokens are declared on `:root, [data-theme]` on purpose — they must recompose per theme scope. Do NOT collapse them onto `:root` alone (that bug rendered every non-default theme dark).

Switch themes by setting `data-theme="<id>"` on the app root and persisting `theme` in settings. See THEMES.md → "Applying a theme".

Other token files (`fonts.css`, `typography.css`, `spacing.css`) and `styles.css` (the `@import` entry point) round out the system. `guidelines/*.html` are visual specimen cards for each token group — reference, not code.

## Primary task this handoff adds
Build the **Theme Picker** view described at the bottom of `THEMES.md`: a scrollable grid of cards, each rendered in its own theme (`data-theme` wrapper), showing a swatch row + a live writing-surface specimen (including the Typewriter active line in `--typewriter-focus`). Clicking a card applies + persists the theme with the `--dur-theme` cross-fade. The project-root file `Themes.dc.html` (in the design project, not this folder) is the visual reference for card + grid layout.

## Rules
- Tokens are the source of truth for color/spacing/type — reference them, don't inline hex.
- Match measurements and copy exactly (README is precise).
- The bundled `.dc.html` files use a custom design-component runtime (`support.js`); treat them as visual references, not code to run in the app.
